
import time
import requests
from bs4 import BeautifulSoup
from telegram import Bot

# =========================
# CONFIGURACIÓN
# =========================

TELEGRAM_TOKEN = "PON_AQUI_TU_TOKEN"
CHAT_ID = "PON_AQUI_TU_CHAT_ID"

# URL base de Futsal Català
URL = "https://www.futsal.cat/resultats"

# Palabras clave para filtrar Tarragona
KEYWORDS = [
    "Tarragona",
    "Reus",
    "Salou",
    "Cambrils",
    "Valls",
    "Tortosa",
    "El Vendrell",
    "Constantí",
    "Torredembarra"
]

CHECK_INTERVAL = 900  # 15 minutos

# =========================
# TELEGRAM
# =========================

bot = Bot(token=TELEGRAM_TOKEN)

# Guardar partidos ya enviados
sent_matches = set()


def get_matches():
    matches = []

    try:
        response = requests.get(URL, timeout=15)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")

        text = soup.get_text(separator="\n")

        lines = text.splitlines()

        for line in lines:
            line = line.strip()

            if not line:
                continue

            # Filtrar partidos senior y Tarragona
            if "Senior" in line:
                for keyword in KEYWORDS:
                    if keyword.lower() in line.lower():
                        matches.append(line)
                        break

    except Exception as e:
        print(f"Error obteniendo partidos: {e}")

    return list(set(matches))


def send_telegram_message(message):
    try:
        bot.send_message(chat_id=CHAT_ID, text=message)
        print(f"Enviado: {message}")
    except Exception as e:
        print(f"Error enviando mensaje: {e}")


def main():
    print("Bot iniciado...")

    while True:
        matches = get_matches()

        for match in matches:
            if match not in sent_matches:
                send_telegram_message(f"⚽ Nuevo partido detectado:\n\n{match}")
                sent_matches.add(match)

        time.sleep(CHECK_INTERVAL)


if __name__ == "__main__":
    main()
