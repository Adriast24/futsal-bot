
# Bot Telegram - Fútbol Sala Tarragona

## Qué hace
Este bot revisa automáticamente la web de Futsal Català y te avisa por Telegram cuando detecta partidos senior relacionados con Tarragona.

---

# Instalación

## 1. Instalar Python
Descarga Python:
https://www.python.org/downloads/

Marca la opción:
- "Add Python to PATH"

---

## 2. Instalar dependencias

Abre CMD o Terminal dentro de la carpeta del proyecto y ejecuta:

```bash
pip install python-telegram-bot requests beautifulsoup4
```

---

## 3. Crear bot de Telegram

1. Busca en Telegram:
@BotFather

2. Escribe:
`/newbot`

3. Pon nombre y username

4. Copia el TOKEN que te da

---

## 4. Obtener tu CHAT ID

Busca en Telegram:
@userinfobot

Te dará tu ID.

---

## 5. Configurar el script

Abre:
`futsal_bot.py`

Y sustituye:

```python
TELEGRAM_TOKEN = "PON_AQUI_TU_TOKEN"
CHAT_ID = "PON_AQUI_TU_CHAT_ID"
```

---

# Ejecutar

```bash
python futsal_bot.py
```

---

# Opcional: ejecutar 24/7

Puedes usar:
- Raspberry Pi
- VPS barato
- Oracle Cloud Free
- Railway
- Render

---

# Ideas futuras

Puedes añadir:
- Resultados en directo
- Clasificación
- Cambios de horario
- Solo ciertos equipos
- Distancia máxima
- Panel web
